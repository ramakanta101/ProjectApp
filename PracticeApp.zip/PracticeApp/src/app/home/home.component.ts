import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute,Params } from '@angular/router';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private route:ActivatedRoute, private router: Router) { }
  userInfo ; 
  ngOnInit() {
    this.route.params.subscribe(val=>{
      this.userInfo =  JSON.parse(localStorage.getItem('userList')).find(user=> user.userName == val.userName);
    })
  }
logout(){
	this.router.navigate(['login'])
}
}