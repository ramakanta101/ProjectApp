import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  constructor(private formBuilder: FormBuilder, private router: Router) { }

 
  loginForm: FormGroup = this.formBuilder.group({
    userName: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(8)]]
  });

  get formControls() { return this.loginForm.controls; }
doSignup(){
	
	this.router.navigate(['signup'])
}

  onSubmit() {
    if (this.loginForm.valid) {

      var userDetails =  JSON.parse(localStorage.getItem('userList'));
      var userIndex = userDetails.findIndex(val=> (val.password ==this.loginForm.value.password) && (val.userName == this.loginForm.value.userName || val.mobile == this.loginForm.value.userName || val.email == this.loginForm.value.userName)   )
  if(userIndex >=0){
    alert('login sucess');
    this.router.navigate(['home',userDetails[userIndex].userName])
  }
  else{
	  alert('UserName/MobileNo/Email or Password is wrong '); 
  }


    }
  }

}