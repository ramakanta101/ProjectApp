import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {

  userList = [];

  constructor(private formBuilder: FormBuilder, private router: Router) { }
unamePattern = "^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$";
mPattern="^[0-9]{10}$";
  registerForm: FormGroup = this.formBuilder.group({
    userName: ['', Validators.required],
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8),Validators.pattern(this.unamePattern)]],
    confirmPassword: ['', [Validators.required, Validators.minLength(8)]],
    mobile: ['', Validators.required,,Validators.pattern(this.mPattern)],
    address: ['', [Validators.required, Validators.maxLength(30)]],
	
  });

  get formControls() { return this.registerForm.controls; }
get username() {
     return this.registerForm.get('password');
} 
logout(){
	this.router.navigate(['/login'])
}
showErrormsg=false;
onBlurMethod(){
	
	if(this.registerForm.get('password').value==this.registerForm.get('confirmPassword').value){
		this.showErrormsg=false;
	}
	else{
		
		this.showErrormsg=true;
		
	}
	
}

  onSubmit() {
	 

	  if(this.registerForm.get('password').value==this.registerForm.get('confirmPassword').value){
       if (this.registerForm.valid) {
		   
		   this.userList=JSON.parse(localStorage.getItem("userList"));
		
        this.userList.push(this.registerForm.value);
        localStorage.setItem('userList', JSON.stringify(this.userList));
        alert('signup success');
        this.router.navigate(['/login'])

    // } 
  }
}
else{
	alert("Password Mismatch");
}


}
}